package com.att;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class SSLRestClient  implements JavaDelegate  {

	public void execute(DelegateExecution execution) throws Exception {
		String url= "https://104.130.165.65:8443/aai/v8/business/customers/customer/";
		String globalCustomerId =(String) execution.getVariable("globalcustomerid");
		url=url+globalCustomerId;
		disableSslVerification();
		String response =netClientGetUrl(url);
		System.out.println("##########################\n");
		System.out.println(response);
		System.out.println("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
		if(response.length()>3999)
		{
		response=response.substring(0, 3999);
		}
		System.out.println(response);
		System.out.println("\n##########################\n");
		execution.setVariable("response", response);
	}
	
	static  String  netClientGetUrl(String url1){
	// System.out.println("Inside netClientGetUrl(String url1, String parameter, String url2)");
	 
	 String response=null;
	   try {
		   		System.out.println("Inside netClintseturl try");
		   		String serviceresponse = null;	
			 	URL url = new URL(url1);
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Accept", "application/json");
				conn.setRequestProperty("content-type", "application/json");
				conn.setRequestProperty("x-fromappid", "VID");
				conn.setRequestProperty("x-transactionid", "11112");
				conn.setRequestProperty("authorization ", "Basic VklEOlZJRA==");
				if (conn.getResponseCode() != 200) {
					System.out.println("Error#9");
					throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
				}
				BufferedReader br = new BufferedReader(new InputStreamReader(
						(conn.getInputStream())));
				while ((serviceresponse = br.readLine()) != null) {
					response=serviceresponse;
				}
				conn.disconnect();
			} catch (MalformedURLException e) {
				System.out.println("Error#10");
				System.out.println(e.getMessage());
			} catch (IOException e) {
				System.out.println("Error#11");
				System.out.println(e.getMessage());
				
			}
	 return response;
 }
	
	
	private static void disableSslVerification() {
	    try
	    {
	        // Create a trust manager that does not validate certificate chains
	        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {
	            }
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {
	            }
	        }
	        };

	        // Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };

	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } catch (KeyManagementException e) {
	        e.printStackTrace();
	    }
	}
	

}
