'use strict';

var assign = require('lodash/object/assign');
var cmdHelper = require('bpmn-js-properties-panel/lib/helper/CmdHelper');
var elementHelper = require('bpmn-js-properties-panel/lib/helper/ElementHelper'),
isObject = require('lodash/lang/isObject'),
labelUtil = require('bpmn-js/lib/features/label-editing/LabelUtil');

/**
 * A palette that allows you to create BPMN _and_ custom elements.
 */
function PaletteProvider(palette, create, elementFactory, spaceTool, lassoTool, handTool, globalConnect, translate) {

    this._palette = palette;
    this._create = create;
    this._elementFactory = elementFactory;
    this._spaceTool = spaceTool;
    this._lassoTool = lassoTool;
    this._handTool = handTool;
    this._globalConnect = globalConnect;
    this._translate = translate;

    palette.registerProvider(this);
}

module.exports = PaletteProvider;

PaletteProvider.$inject = [
  'palette',
  'create',
  'elementFactory',
  'spaceTool',
  'lassoTool',
  'handTool',
  'globalConnect',
  'translate'
];


PaletteProvider.prototype.getPaletteEntries = function (element) {

    var actions = {},
        create = this._create,
        elementFactory = this._elementFactory,
        spaceTool = this._spaceTool,
        lassoTool = this._lassoTool,
        handTool = this._handTool,
        globalConnect = this._globalConnect,
        translate = this._translate;


    function createAction(type, group, className, title, options) {

    function createListener(event) {
      var shape = null;
      if (/^custom\:/.test(type)) {
	        shape = elementFactory.createShape({ type: "bpmn:CallActivity" });
        assign(shape.businessObject, {
            //class: "com.MyClass"
        });
	 if (options.labelText) {
        labelUtil.setLabel(shape, options.labelText);
      }
       //attach moddle attributes
      if (isObject(options.moddleAttrs)) {
        each(options.moddleAttrs, function(val, key) {
          shape.businessObject.set(key, val);
        });

      }


      } else {
        shape = elementFactory.createShape(assign({ type: type }, options));
      }

      if (options && options.isExpanded) {
        shape.businessObject.di.isExpanded = options.isExpanded;
      }

      create.start(event, shape);

    }

    var shortType = type.replace(/^bpmn\:/, '');

    return {
      group: group,
      className: className,
      title: title || 'Create ' + shortType,
      action: {
        dragstart: createListener,
        click: createListener
      }
    };

  }

  function createParticipant(event, collapsed) {
    create.start(event, elementFactory.createParticipantShape(collapsed));
  }

  
    assign(actions, {
        'hand-tool': {
          group: 'tools',
          className: 'bpmn-icon-hand-tool',
          title: translate('Activate the hand tool'),
          action: {
            click: function(event) {
              handTool.activateHand(event);
            }
          }
        },
        'lasso-tool': {
            group: 'tools',
            className: 'bpmn-icon-lasso-tool',
            title: 'Activate the lasso tool',
            action: {
                click: function (event) {
                    lassoTool.activateSelection(event);
                }
            }
        },
        'space-tool': {
            group: 'tools',
            className: 'bpmn-icon-space-tool',
            title: 'Activate the create/remove space tool',
            action: {
                click: function (event) {
                    spaceTool.activateSelection(event);
                }
            }
        },
        'global-connect-tool': {
          group: 'tools',
          className: 'bpmn-icon-connection-multi',
          title: translate('Activate the global connect tool'),
          action: {
            click: function(event) {
              globalConnect.toggle(event);
            }
          }
        },
 	'tool-separator': {
            group: 'tools',
            separator: true
        },  
       'create.start-event': createAction(
            'bpmn:StartEvent', 'event', 'bpmn-icon-start-event-none', 'custom start event'
        ),
        'create.intermediate-event': createAction(
            'bpmn:IntermediateThrowEvent', 'event', 'bpmn-icon-intermediate-event-none'
        ),
        'create.end-event': createAction(
            'bpmn:EndEvent', 'event', 'bpmn-icon-end-event-none'
        ),
        'create.exclusive-gateway': createAction(
            'bpmn:ExclusiveGateway', 'gateway', 'bpmn-icon-gateway-xor'
        ),
        'create.servicetask': createAction(
            'bpmn:ServiceTask', 'activity', 'bpmn-icon-service-task'
        ),
        'create.data-object': createAction(
            'bpmn:DataObjectReference', 'data-object', 'bpmn-icon-data-object'
        ),
 'custom-separator': {
      group: 'custom',
      separator: true
    },

     'create-diagnose-service-task': createAction(
      'custom:diagnoseservicetask', 'custom', 'diagnose', 'Diagnose',{
        labelText: 'Diagnose'
        
      }
    ),
    'create-ticket-Services-Task': createAction(
      'custom:ticketservicestask', 'custom', 'ticketService', 'GetA&AIServices',{
        labelText: 'GetA&AIServices'
       
      }

    ),
'create-inventory-task': createAction(
      'custom:inventorytask', 'custom', 'inventory', 'Inventory',{
        labelText: 'Inventory'
        
      }
    ),
'create-adaptors-task': createAction(
      'custom:adaptorstask', 'custom', 'adaptors', 'Adaptors',{
        labelText: 'Adaptors'
        
      }
    )
    });

    return actions;
};